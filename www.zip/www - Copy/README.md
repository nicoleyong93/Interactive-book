This is an interactive children book app.
It's a children story about the 12 Chinese Zodiac and how they got their name for the years.

xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

by Nicole Yong
Interactive multimedia design student
Taylor's University Lakeside Campus